<div id='SideBar'>
      <span class= 'SideBarButns btn btn-warning' id=SideBarText-Genres>Жанры</span><br>
      <span class="AllGenres SideBarButns btn btn-outline-warning" data-toggle="button" aria-pressed="false" autocomplete="off" id="Drama" >Драма</span></br>
      <span class="AllGenres SideBarButns btn btn-outline-warning" data-toggle="button" aria-pressed="false" autocomplete="off" id="Fantasy">Фэнтези</span><br>
      <span class="AllGenres SideBarButns btn btn-outline-warning" data-toggle="button" aria-pressed="false" autocomplete="off" id="Action">Экшен</span><br>
      <span class="AllGenres SideBarButns btn btn-outline-warning" data-toggle="button" aria-pressed="false" autocomplete="off" id="Daily">Повседневность</span><br>
    </div>