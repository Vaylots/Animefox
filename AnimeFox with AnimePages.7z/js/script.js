$(document).ready(function() { 
$('#SideBar').hide();
  $('#SideBarAlert').hover(function() {
  $("#SideBar").toggle("slide",200);
  });



$('#SAO').hide();
  $('#butns').click(function() {
    location.href = "../AnimePages/Sword Art Online/Sao-Page.php";
  });



$('#VE').hide();
  $('#butnv').click(function() {
  location.href = "../AnimePages/Violet Evergarden/Violet-Page.php";
  });



$('#akame').hide();
  $('#butna').click(function() {
  location.href = "../AnimePages/Akame ga Kill!/Akame-Page.php";
  });



$('#jojo').hide();
  $('#butnj').click(function() {
  location.href = "../AnimePages/JOJO/Jojo-Page.php";
  });




$('.Drama').hide();
  $('#Drama').click(function() {
  $(".Drama").slideToggle(200);
  });


 
$('.Action').hide();
  $('#Action').click(function() {
  $(".Action").slideToggle(200);
  });



$('.Fantasy').hide();
  $('#Fantasy').click(function() {
  $(".Fantasy").slideToggle(200);
  });



$('.Daily').hide();
  $('#Daily').click(function() {
  $(".Daily").slideToggle(200);
  });

});

$('#butnjC').show();
  $('#butnj').click(function() {
    $("#butnjC").slideToggle(300);
  });