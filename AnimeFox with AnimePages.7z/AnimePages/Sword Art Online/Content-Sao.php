<div class="content" id="content">
      <div class="anime">
        <div><img class=" anime-image img-fluid" src="../../images/Anime/Sword Art Online.jpg"></div>
        <div class="Anime-Name">Sword Art Online</div>
        <img class= "card-rate img-fluid" src= "https://i.imgur.com/WvTjXH4.png" > 
        <div class="Anime-Description">
          <script type="text/javascript" src="../../js/jstextSao.js"></script>
        </div>
         <div>
          <?
          include "Screenshots-Sao.php"
         ?>
       </div>
      </div>


    </div>