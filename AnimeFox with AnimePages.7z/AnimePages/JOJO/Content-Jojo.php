<div class="content" id="content">
      <div class="anime">
        <div><img class=" anime-image img-fluid" src="../../images/Anime/JOJO.jpg"></div>
        <div class="Anime-Name">JoJo no Kimyou na Bouken</div>
        <img class= "card-rate img-fluid" src= "https://i.imgur.com/VKajsMh.png" > 
        <div class="Anime-Description">
          <script type="text/javascript" src="../../js/jstextJoJo.js"></script>
        </div>
         <div>
          <?
          include "Screenshots-Jojo.php"
         ?>
       </div>
      </div>


    </div>