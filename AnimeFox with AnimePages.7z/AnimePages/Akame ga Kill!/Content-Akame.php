<div class="content" id="content">
      <div class="anime">
        <div><img class=" anime-image img-fluid" src="../../images/anime/akame ga kill!.jpg"></div>
        <div class="Anime-Name">Akame ga Kill!</div>
        <img class= "card-rate img-fluid" src= "https://i.imgur.com/HlByv7Y.png" > 
        <div class="Anime-Description">
          <script type="text/javascript" src="../../js/jstextAkame.js"></script>
        </div>
         <div>
          <?
          include "Screenshots-Akame.php"
         ?>
       </div>
      </div>


    </div>