<div class="content" id="content">
      <div class="anime">
        <div><img class=" anime-image img-fluid" src="../../images/Anime/Violet Evergarden.jpg"></div>
        <div class="Anime-Name">Sword Art Online</div>
        <img class= "card-rate img-fluid" src= "https://i.imgur.com/WvTjXH4.png" > 
        <div class="Anime-Description">
          <script type="text/javascript" src="../../js/jstextViolet.js"></script>
        </div>
         <div>
          <?
          include "Screenshots-Violet.php"
         ?>
       </div>
      </div>


    </div>