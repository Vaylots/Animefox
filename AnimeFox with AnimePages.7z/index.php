<!DOCTYPE html>

<html>


<head>
 <script type="text/javascript"  src="js/jquery-3.5.1.js" ></script>
 <script type="text/javascript" src="js/jquery-ui.js"></script>
 <script type="text/javascript" src="js/script.js"></script>
 <script type="text/javascript" src="js/bootstrap.js"></script>
 <link rel="stylesheet" type="text/css" href="css/Style.css">
 <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
 <link rel="shortcut icon" href="images/Logo/icon.png" type="image/png">
 <meta charset="UTF-8">
 <title>AnimeFox</title>
</head>


<body>
  <header>
    <div>
      <img class="col-lg-1 col-sm-12" id=Logo src="images/Logo/Logo.png">
    </div>
  </header>


  <div id='SideBarAlert'>
    <?
    include "SideBar.php"
    ?>
  </div>

<div class="container">
  <div  id="Popular">
<?
 include 'popular.php'
?>
</div>


<?
 include 'Anime card.php'
?>
</div>



</body>



</html>
