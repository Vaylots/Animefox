  <div class="row">
   <div class="col-lg-4 col-md-2  Action">
    <section class= "content">
      <div class = card>
        <div>
          <img class= card-image src= "images/anime/Sword Art Online.jpg" >  
        </div>
        <div>
          <img class= "card-rate img-fluid" src= "https://i.imgur.com/WvTjXH4.png" > 
        </div>

        <h3 class= card-title>Sword art Online</h3>
        <div class= card-text id= "SAO" > 
          <div class="Screenshots">
          <div id="carouselSaoIndicators" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
              <li data-target="#carouselSaoIndicators" data-slide-to="0" class="active"></li>
              <li data-target="#carouselSaoIndicators" data-slide-to="1"></li>
              <li data-target="#carouselSaoIndicators" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner">
              <div class="carousel-item active">
                <img src="images/Screenshots/Sao/1.jpg" class="d-block w-100" alt="...">
              </div>
              <div class="carousel-item">
                <img src="images/Screenshots/Sao/2.jpg" class="d-block w-100" alt="...">
              </div>
              <div class="carousel-item">
                <img src="images/Screenshots/Sao/3.jpg" class="d-block w-100" alt="...">
              </div>
            </div>
            <a class="carousel-control-prev" href="#carouselSaoIndicators" role="button" data-slide="prev">
              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
              <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselSaoIndicators" role="button" data-slide="next">
              <span class="carousel-control-next-icon" aria-hidden="true"></span>
              <span class="sr-only">Next</span>
            </a>
          </div>
          </div>
          <script type="text/javascript" src="js/jstextSao.js"></script>
        </div>
      </div>
      <div class="btn btn-primary butn More"id='butns'>Подробнее</div>
    </section>
    
  </div>

  <div class="col-lg-4  Drama Daily ">
   <section class= "content ">
     <div class = card >
      <div>
        <img class= card-image src= "images/anime/Violet Evergarden.jpg" >  
      </div>
      <div> 
        <img class= "card-rate img-fluid" src= "https://i.imgur.com/sTz1MJu.png" > 
      </div>

      <h3 class= card-title>Violet Evergarden</h3>
      <div class= card-text id= "VE"> 
       <div class="Screenshots">
          <div id="carouselVioletIndicators" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
              <li data-target="#carouselVioletIndicators" data-slide-to="0" class="active"></li>
              <li data-target="#carouselVioletIndicators" data-slide-to="1"></li>
              <li data-target="#carouselVioletIndicators" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner">
              <div class="carousel-item active">
                <img src="images/Screenshots/Violet Evergarden/1.jpg" class="d-block w-100" alt="...">
              </div>
              <div class="carousel-item">
                <img src="images/Screenshots/Violet Evergarden/2.jpg" class="d-block w-100" alt="...">
              </div>
              <div class="carousel-item">
                <img src="images/Screenshots/Violet Evergarden/3.jpg" class="d-block w-100" alt="...">
              </div>
            </div>
            <a class="carousel-control-prev" href="#carouselVioletIndicators" role="button" data-slide="prev">
              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
              <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselVioletIndicators" role="button" data-slide="next">
              <span class="carousel-control-next-icon" aria-hidden="true"></span>
              <span class="sr-only">Next</span>
            </a>
          </div>
          </div>
        <script type="text/javascript" src="js/jstextViolet.js"></script>
      </div>
    </div>
    <div class="btn btn-primary butn More"id='butnv'>Подробнее</div>
  </section>
</div>

<div class="col-lg-4 Fantasy" >
 <section class= "content  ">
  <div class = card>
    <div>
      <img class= card-image  src= "images/anime/akame ga kill!.jpg">  
    </div>
    <div> 
      <img class= "card-rate img-fluid" src= "https://i.imgur.com/HlByv7Y.png" >
    </div> 
    <h3 class= card-title>Akame ga Kill!</h3>
    <div class= card-text id="akame"> 
      <div class="Screenshots">
          <div id="carouselAkameIndicators" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
              <li data-target="#carouselAkameIndicators" data-slide-to="0" class="active"></li>
              <li data-target="#carouselAkameIndicators" data-slide-to="1"></li>
              <li data-target="#carouselAkameIndicators" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner">
              <div class="carousel-item active">
                <img src="images/Screenshots/Akame/1.jpg" class="d-block w-100" alt="...">
              </div>
              <div class="carousel-item">
                <img src="images/Screenshots/Akame/2.jpg" class="d-block w-100" alt="...">
              </div>
              <div class="carousel-item">
                <img src="images/Screenshots/Akame/3.jpg" class="d-block w-100" alt="...">
              </div>
            </div>
            <a class="carousel-control-prev" href="#carouselAkameIndicators" role="button" data-slide="prev">
              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
              <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselAkameIndicators" role="button" data-slide="next">
              <span class="carousel-control-next-icon" aria-hidden="true"></span>
              <span class="sr-only">Next</span>
            </a>
          </div>
      <script type="text/javascript" src="js/jstextAkame.js"></script>
    </div>
  </div>
  <div class="btn btn-primary butn More"id="butna">Подробнее</div>
</section>
</div>


<div class="col-lg-4 Action">
  <section class= "content ">
    <div class = card>
      <div>
        <img class= card-image src= "images/anime/JoJo.jpg" >  
      </div>
      <div> 
        <img class= "card-rate img-fluid" src= "https://i.imgur.com/VKajsMh.png" > 
      </div>

      <h3 class= card-title>JoJo no Kimyou na Bouken</h3>
      <div class= card-text id="jojo"> 
        <div class="Screenshots">
          <div id="carouselJoJoIndicators" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
              <li data-target="#carouselJoJoIndicators" data-slide-to="0" class="active"></li>
              <li data-target="#carouselJoJoIndicators" data-slide-to="1"></li>
              <li data-target="#carouselJoJoIndicators" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner">
              <div class="carousel-item active">
                <img src="images/Screenshots/JoJo/1.jpg" class="d-block w-100" alt="...">
              </div>
              <div class="carousel-item">
                <img src="images/Screenshots/JoJo/2.jpg" class="d-block w-100" alt="...">
              </div>
              <div class="carousel-item">
                <img src="images/Screenshots/JoJo/3.jpg" class="d-block w-100" alt="...">
              </div>
            </div>
            <a class="carousel-control-prev" href="#carouselJoJoIndicators" role="button" data-slide="prev">
              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
              <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselJoJoIndicators" role="button" data-slide="next">
              <span class="carousel-control-next-icon" aria-hidden="true"></span>
              <span class="sr-only">Next</span>
            </a>
          </div>  
        <script type="text/javascript" src="js/jstextJoJo.js"></script>
      </div>
    </div>
    <div class="btn btn-primary butn More " id="butnj">Подробнее</div>
    
  </section>
</div>

</div>