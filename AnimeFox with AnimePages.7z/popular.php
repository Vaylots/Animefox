    
  <div class='row'>
  <div class='col-lg-12'>
    <div id='Popular-Text'>Что сейчас популярно</div>
    <div  id=Popular-anime>
      <div class= 'Popular-anime-card' id="Kaguya">
        <a href="#"><img class='Popular-anime-image img-fluid' src="images/anime/Kague.jpg"></a>
        <div class="Popular-anime-name">Kaguya-sama wa Kokurasetai?: Tensai-tachi no Renai Zunousen</div>
      </div>

      <div class= 'Popular-anime-card' id="Haikyuu!!">
       <a href="#"><img class='Popular-anime-image img-fluid' src="images/anime/Haikyuu.jpg"></a>
       <div class="Popular-anime-name">Haikyuu!!: To the Top 2nd Season</div>
     </div>

     <div class= 'Popular-anime-card' id="Re:Zero">
       <a href="#"> <img class='Popular-anime-image img-fluid' src="images/anime/Re-Zero.jpg"></a>
       <div class="Popular-anime-name">Re:Zero kara Hajimeru Isekai Seikatsu 2nd Season </div>
     </div>

     <div class= 'Popular-anime-card' id="Fruit Basket">
      <a href="#"><img class='Popular-anime-image img-fluid' src="images/anime/Fruit Basket.jpg"></a>
      <div class="Popular-anime-name">Fruits Basket 2nd Season</div>
    </div>

    <div class= 'Popular-anime-card' id="Yahare">
      <a href="#"> <img class='Popular-anime-image img-fluid' src="images/anime/Yahare.jpg"></a> 
      <div class="Popular-anime-name">Yahari Ore no Seishun Love Comedy wa Machigatteiru. Kan</div>
    </div>

    <div class= 'Popular-anime-card' id="Great Pretender">
      <a href="#"><img class='Popular-anime-image img-fluid' src="images/anime/Great Pretender.jpg"></a>  
      <div class="Popular-anime-name">Great Pretender</div>
    </div>



  </div>

  </div>

  </div>
